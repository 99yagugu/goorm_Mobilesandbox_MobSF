Java.perform(function() {
  // Use send() for logging
});